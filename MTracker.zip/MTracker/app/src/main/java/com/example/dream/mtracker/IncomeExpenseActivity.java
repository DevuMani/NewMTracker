package com.example.dream.mtracker;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.transition.Explode;
import android.transition.Fade;
import android.transition.Slide;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import net.steamcrafted.materialiconlib.MaterialDrawableBuilder;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class IncomeExpenseActivity extends AppCompatActivity {

    static String g_date="";

    TextView income;
    TextView expense;
    TextView currency;
    static TextView save_date;
    Switch data_switch;
    EditText amount, desc;
    FloatingActionButton save;


    RecyclerView category_list;
    ArrayList<Category_Data> myIconList;
    GridLayoutManager gridLayoutManager;
    CategoryListAdapter adapter;

    public static String iconsymbol = "";

    static LinearLayout linearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        animation();
        setContentView(R.layout.activity_income_expense);

        initView();

        init();

        setDefaultDate();
//        setIconToList();

        data_switch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                switchCheck();

            }
        });

        save_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DialogFragment newFragment = new DatePickerFragment();
                newFragment.show(getFragmentManager(), "datePicker");
            }
        });


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                saveFunction();
            }
        });

    }

    private void setDefaultDate() {

        Calendar c = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("dd MMM yyyy");

        String date=format.format(c.getTime());

        save_date.setText(date);
    }


    private void init() {

        myIconList = new ArrayList<>();
        setIconToList();
        gridLayoutManager = new GridLayoutManager(IncomeExpenseActivity.this, 2,GridLayoutManager.HORIZONTAL,false);

        adapter = new CategoryListAdapter(IncomeExpenseActivity.this, myIconList);

        category_list.setLayoutManager(gridLayoutManager);
        category_list.setAdapter(adapter);


    }

    private void initView() {

        income = findViewById(R.id.income_text);
        expense = findViewById(R.id.expense_text);
        data_switch = findViewById(R.id.expenditure_switch);
        currency = findViewById(R.id.expenditure_currency);
        save_date = findViewById(R.id.expenditure_date);
        amount = findViewById(R.id.expenditure_amount);
        desc = findViewById(R.id.expenditure_description);
        save = findViewById(R.id.expenditure_save);

        category_list = findViewById(R.id.expenditure_category_list);

        linearLayout = findViewById(R.id.expenditure_linearLayout);

        switchCheck();
    }

    public void switchCheck() {

        Boolean b = data_switch.isChecked();

        if (b == true) {
            expense.setTextColor(Color.RED);
            income.setTextColor(Color.BLACK);

        } else {
            income.setTextColor(getResources().getColor(R.color.green));
            expense.setTextColor(Color.BLACK);
        }

        init();

    }

    public void setIconToList() {

        Category_Data c_data;
        int type_id=-1;


        myIconList = new ArrayList<>();

        DBFunction dbFunction=new DBFunction(IncomeExpenseActivity.this);

        Boolean transaction= data_switch.isChecked();


        if(transaction==true)
        {
//            fetch id of expense from category table
            type_id=dbFunction.fetchTypeID("expense");

        }
        else
        {
            type_id=dbFunction.fetchTypeID("income");
        }

        if(type_id==-1)
        {
            Log.e("Error Fetching id",""+type_id);
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show();
        }
        else
        {
//            Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show();
                myIconList=dbFunction.categoryFetch(type_id);

        }



//        while(cursor.moveToNext()) {
//
//            c_data = new Category_Data();
//
//            c_data.setCategory_id(cursor.getInt(0));
//            c_data.setCategory_name(cursor.getString(1));
//            c_data.setForeground_color(cursor.getString(2));
//            c_data.setBackground_color(cursor.getString(3));
//
//
//            myIconList.add(c_data);
//
//        }



    }

    private void animation() {

        Slide slide = new Slide(Gravity.LEFT);
        slide.setDuration(250);
        getWindow().setEnterTransition(slide);

        Fade fade=new Fade();
        fade.setDuration(300);
        getWindow().setExitTransition(fade);
    }

    public static class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {

        public Dialog onCreateDialog(Bundle savedInstanceState) {
            //Use the current date as the default date in the picker
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(getActivity(), this, year, month, day);


        }

        @Override
        public void onDateSet(DatePicker view, int year, int month, int day) {

            Calendar c = Calendar.getInstance();
            Calendar calendar = Calendar.getInstance();
            calendar.set(year, month, day);

            month=month+1;//because month value is got as 9 if oct is selected
            String mon="";

            if(month<10)
            {
                mon="0";
            }

            String d="";
            if(day<10)
            {
                d="0";
            }

            g_date=year+"-"+mon+month+"-"+d+day;


            SimpleDateFormat format = new SimpleDateFormat("dd MMM yyyy");

            String date=format.format(calendar.getTime());

            Date date_1=null;
            try {
                date_1=format.parse(date);
            } catch (ParseException e) {
                e.printStackTrace();
            }


//            if(date_1.compareTo(c.getTime()) >= 0)
//            {
//                Snackbar snackbar = Snackbar
//                        .make(linearLayout, "Can't enter for days after today", Snackbar.LENGTH_LONG);
//
//                snackbar.show();
//
//
//            }
//            else
//            {
                save_date.setText(date);
//            }


        }


    }

    private void saveFunction() {

        //Flag to set as true if all values are valid
        Boolean fail=false;

//        int type_id=0;
        int cat_id=0;

        DBFunction dbFunction=new DBFunction(IncomeExpenseActivity.this);

        String tb_amount=amount.getText().toString();
        String tb_desc=desc.getText().toString();
        String tb_categories= iconsymbol;



        cat_id=dbFunction.fetchCategoryId(tb_categories);


        String date=save_date.getText().toString();

        SimpleDateFormat format = new SimpleDateFormat("dd MMM yyyy");

        Date tb_date=null;

        try {
            tb_date = format.parse(date);

        } catch (ParseException e) {
            e.printStackTrace();
        }



        if(tb_amount.equals(""))
        {
            Toast.makeText(this, "Fill an amount ", Toast.LENGTH_SHORT).show();
            fail=true;
        }
        else if (tb_categories.equals(""))
        {
            Toast.makeText(this, "Choose a category", Toast.LENGTH_SHORT).show();
            fail=true;
        }
        else if (tb_date==null)
        {
            Toast.makeText(this, "Choose a date", Toast.LENGTH_SHORT).show();
            fail=true;
        }


        if(fail==false) {

            Toast.makeText(this, "Category id "+cat_id, Toast.LENGTH_SHORT).show();
            Toast.makeText(this, "Amount "+tb_amount, Toast.LENGTH_SHORT).show();
            Toast.makeText(this, "Description "+tb_desc, Toast.LENGTH_SHORT).show();
            Toast.makeText(this, "Categories "+tb_categories, Toast.LENGTH_SHORT).show();
            Toast.makeText(this, "Date "+tb_date, Toast.LENGTH_SHORT).show();

//            Boolean b= dbFunction.expenditureInsert(cat_id, tb_amount, tb_desc, tb_date);
            Boolean b= dbFunction.expenditureInsert(cat_id, tb_amount, tb_desc, g_date);
//            Toast.makeText(this, "Fail "+fail, Toast.LENGTH_SHORT).show();

            if (b == true) {

                Toast.makeText(this, "Successfully inserted expenditure ", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(this,Home.class);
                startActivity(intent);
                finish();

            } else {
                Toast.makeText(this, "Expenditure insertion failed", Toast.LENGTH_SHORT).show();

            }
        }
        else
        {
            Toast.makeText(this, "Enter valid data's", Toast.LENGTH_SHORT).show();
        }




    }

}
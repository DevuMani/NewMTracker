package com.example.dream.mtracker;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

public class Home_detail extends AppCompatActivity {

    FloatingActionButton fab;
    RecyclerView month_detail;
    LinearLayoutManager linearLayoutManager;


    ArrayList<Month_Data> myMonth;
    ArrayList<Month_Data> myMonthData;
    String date="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_month);


        initView();

        init();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Home_detail.this,IncomeExpenseActivity.class);
                startActivity(intent);
            }
        });
    }

    private void init() {

//        myMonth=new ArrayList<>();
        myMonthData = new ArrayList<>();
        setDateToList();

        linearLayoutManager = new LinearLayoutManager(this, OrientationHelper.VERTICAL,false);
        HomeDetailAdapter adapter= new HomeDetailAdapter(this,myMonthData);

        month_detail.setLayoutManager(linearLayoutManager);
        month_detail.setAdapter(adapter);


    }

    private void setDateToList() {

        DBFunction dbFunction=new DBFunction(this);

//        myMonth = new ArrayList<>();
        myMonthData = new ArrayList<>();

//        myMonth=dbFunction.fetchMonth(date);
        myMonthData=dbFunction.fetchMonthData(date);
    }

    private void initView() {

        fab=findViewById(R.id.button_month_expenditure);
        month_detail=findViewById(R.id.month_recyclerView);

        date=getIntent().getStringExtra("Date");

        Toast.makeText(this, "Date home "+date, Toast.LENGTH_SHORT).show();
    }
}

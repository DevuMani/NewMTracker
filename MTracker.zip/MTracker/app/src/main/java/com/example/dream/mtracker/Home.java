package com.example.dream.mtracker;

import android.app.ActivityOptions;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.transition.Fade;
import android.transition.Slide;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;

public class Home extends AppCompatActivity implements View.OnClickListener {

    FloatingActionButton fab;
    TextView year_text;
    RecyclerView year_list;
    ImageView imageView;
    LinearLayoutManager linearLayoutManager;
    RelativeLayout left_click,right_click;
    ArrayList<Home_Year_Data> myYearData;

    int year=0;

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent intent=new Intent(this,GoogleHome.class);
        intent.putExtra("Type","firebase");
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_year);

//        Intent notifyIntent = new Intent(this, MyReceiver.class);
//        PendingIntent pendingIntent = PendingIntent.getBroadcast
//                (this, 0 , notifyIntent, PendingIntent.FLAG_UPDATE_CURRENT);
//        AlarmManager alarmManager = (AlarmManager) this.getSystemService(this.ALARM_SERVICE);
//
//        Calendar calendar = Calendar.getInstance();
//        calendar.setTimeInMillis(System.currentTimeMillis());
////            calendar.set(Calendar.HOUR_OF_DAY, 21);
//        calendar.set(Calendar.HOUR_OF_DAY, 23);
//        calendar.set(Calendar.MINUTE,05);
//        calendar.set(Calendar.SECOND, 1);
//
//
//        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,  calendar.getTimeInMillis(),
//                AlarmManager.INTERVAL_DAY, pendingIntent);

        initView();

        init();

        animation();

        DBFunction dbFunction=new DBFunction(this);
        dbFunction.display();

        //dbFunction.setIconName();





        left_click.setOnClickListener(this);
        right_click.setOnClickListener(this);
        fab.setOnClickListener(this);
    }

    private void animation() {

        Slide slide = new Slide(Gravity.LEFT);
        slide.setDuration(250);
        getWindow().setReenterTransition(slide);

        Fade fade=new Fade();
        fade.setDuration(2000);
        getWindow().setExitTransition(fade);
    }


    private void initView() {

        fab=findViewById(R.id.button_year_expenditure);
        year_list=findViewById(R.id.year_recyclerView);
        year_text=findViewById(R.id.home_year_text);
        left_click=findViewById(R.id.left_side);
        right_click=findViewById(R.id.right_side);
        imageView=findViewById(R.id.home_no_data);
        imageView.setVisibility(View.GONE);
        year= Calendar.getInstance().get(Calendar.YEAR);
        year_text.setText(""+year);

    }

    private void init() {

        myYearData = new ArrayList<>();

        setYearDataToList(year_text.getText().toString());

        linearLayoutManager = new LinearLayoutManager(Home.this);

        if(myYearData.size()==0)
        {
            imageView.setVisibility(View.VISIBLE);
            HomeYearAdapter adapter = new HomeYearAdapter(this, myYearData);
            year_list.setLayoutManager(linearLayoutManager);
            year_list.setAdapter(adapter);
        }
        else {

//            Toast.makeText(this, "Size"+myYearData.size(), Toast.LENGTH_SHORT).show();
            HomeYearAdapter adapter = new HomeYearAdapter(this, myYearData);
            imageView.setVisibility(View.GONE);
            year_list.setLayoutManager(linearLayoutManager);
            year_list.setAdapter(adapter);
        }
    }

    private void setYearDataToList(String year) {

        DBFunction dbFunction=new DBFunction(this);

        myYearData = new ArrayList<>();

        myYearData=dbFunction.fetchYear(year);
//        myYearData=dbFunction.fetchYearWorking();

    }

    @Override
    public void onClick(View view) {

        if(view==left_click)
        {

//            Toast.makeText(this, "Left clicked", Toast.LENGTH_SHORT).show();
            int year1=Integer.parseInt(this.year_text.getText().toString());

            year1=year1+1;

            this.year_text.setText(""+year1);
           init();


        }
        else if (view == right_click)
        {
//            Toast.makeText(this, "Right clicked", Toast.LENGTH_SHORT).show();

            int year1=Integer.parseInt(this.year_text.getText().toString());

            year1=year1-1;

            this.year_text.setText(""+year1);
            init();

        }
        else if (view == fab)
        {
            Bundle bundle= ActivityOptions.makeSceneTransitionAnimation(Home.this).toBundle();
            Intent intent=new Intent(Home.this,IncomeExpenseActivity.class);
            startActivity(intent,bundle);
        }
    }
}

package com.example.dream.mtracker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.mynameismidori.currencypicker.CurrencyPicker;
import com.mynameismidori.currencypicker.CurrencyPickerListener;

public class TestActivity extends AppCompatActivity {

    TextView currency;
    ImageView currency_show;
    Button submit;

    String currency_code="";
    String currency_name="";
    String currency_symbol="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        init();

        currency_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(TestActivity.this, "Currency list coming soon.....", Toast.LENGTH_SHORT).show();

                final CurrencyPicker picker = CurrencyPicker.newInstance("Select Currency");  // dialog title

                picker.show(getSupportFragmentManager(), "CURRENCY_PICKER");
                picker.setListener(new CurrencyPickerListener() {
                    @Override
                    public void onSelectCurrency(String name, String code, String symbol, int flagDrawableResID) {
                        // Implement your code here

                        currency_code=code;
                        currency_name=name;


                        Toast.makeText(TestActivity.this, "Currency "+name, Toast.LENGTH_SHORT).show();
//                        im_currency.setImageDrawable();

                        if(code.equalsIgnoreCase("INR"))
                        {
                            currency.setText(R.string.Rs);

                            currency_symbol=getString(R.string.Rs);
                        }
                        else {
                            currency.setText(symbol);
                            currency_symbol=symbol;

                        }

                        picker.dismiss();
                    }

                });


            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DBFunction dbFunction=new DBFunction(TestActivity.this);

                dbFunction.insert_currency();
                dbFunction.display();
//                dbFunction.delete();
            }
        });

    }



    private void init() {

        currency=findViewById(R.id.currency_add);
        currency_show=findViewById(R.id.imageView);
//        currency_show.setImageDrawable(getDrawable(R.drawable.currency_japanese_yen));
        submit=findViewById(R.id.test_submit);

        DBFunction dbFunction=new DBFunction(TestActivity.this);
        dbFunction.display();
    }


}

package com.example.dream.mtracker;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import net.steamcrafted.materialiconlib.MaterialDrawableBuilder;
import net.steamcrafted.materialiconlib.MaterialIconView;

import java.util.ArrayList;



/**
 * Created by DevuMani on 10/5/2018.
 */

public class CategoryListAdapter extends RecyclerView.Adapter<CategoryListAdapter.MyViewHolder> {

    private Context mContext;
    private ArrayList<Category_Data> iconList;

    public CategoryListAdapter(Context context, ArrayList<Category_Data> iconList) {

        mContext = context;
        this.iconList = iconList;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(mContext).inflate(R.layout.category_cust_row, parent,false);
        MyViewHolder viewHolder = new MyViewHolder(v);
        return viewHolder;
    }


    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

       Category_Data c_data= iconList.get(position);

       MaterialDrawableBuilder.IconValue a=MaterialDrawableBuilder.IconValue.valueOf(c_data.getCategory_name());

        int color = Color.parseColor(c_data.foreground_color);

        holder.iconView.setIcon(a);
        holder.iconView.setColor(color);
        holder.iconView.setSizeDp(24);

        if(position== getItemCount()-1) {
            holder.iconView.setColor(mContext.getResources().getColor(R.color.green));
            holder.iconView.setSizeDp(60);
        }
    }

    @Override
    public int getItemCount() {
//        Toast.makeText(mContext, "Size"+iconList.size(), Toast.LENGTH_SHORT).show();
        return iconList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public MaterialIconView iconView;
        public String symbol;

        public MyViewHolder(View itemView) {
            super(itemView);

            iconView = itemView.findViewById(R.id.iconView_single_row_iconholder);

            iconView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {

            if(view == iconView)
            {
                Category_Data c_data= iconList.get(getAdapterPosition());

                IncomeExpenseActivity.iconsymbol= String.valueOf(c_data.getCategory_name());

                if(getAdapterPosition()== getItemCount()-1) {
                    Toast.makeText(mContext, "Last", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(mContext,AddCategory.class);
                    mContext.startActivity(intent);
                }
                Toast.makeText(mContext, ""+IncomeExpenseActivity.iconsymbol, Toast.LENGTH_SHORT).show();
//                Toast.makeText(mContext, "Dataa:::"+String.valueOf(iconList.get(getItemCount())), Toast.LENGTH_SHORT).show();
            }
        }
    }

}

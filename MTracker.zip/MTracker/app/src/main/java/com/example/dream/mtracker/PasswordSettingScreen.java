package com.example.dream.mtracker;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class PasswordSettingScreen extends AppCompatActivity {

    String password_check="";
    int set=0;

    TextView password_heading;
    EditText password;
    FloatingActionButton set_fab;

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        password_check="";
        password.setText(password_check);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_setting_screen);

//        DBFunction dbFunction=new DBFunction(this);
//        dbFunction.updatePassword("1234","set");

        password_heading=findViewById(R.id.password_tv);
        password=findViewById(R.id.password_et);
        set_fab=findViewById(R.id.password_next);


        SharedPreferences sharedPreferences = getSharedPreferences("User",MODE_PRIVATE);
        Boolean pass=sharedPreferences.getBoolean("Password",false);

        if(pass == true) {

            if (getIntent().getStringExtra("from").equalsIgnoreCase("splash")) {

                password_heading.setText("Enter Password");
                set=3;

            }
            else if (getIntent().getStringExtra("from").equalsIgnoreCase("clear")){

                        set=5;
                        password_heading.setText("Old password");

            }else if (getIntent().getStringExtra("from").equalsIgnoreCase("profile_change")) {

                Toast.makeText(PasswordSettingScreen.this, "Change password", Toast.LENGTH_SHORT).show();
                set=4;
                password_heading.setText("Old password");

            }
            else if (getIntent().getStringExtra("from").equalsIgnoreCase("profile_set")) {

                password_heading.setText("Set password");

            }

        }
        else
        {
            password_heading.setText("Set password");



        }


        set_fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(set==0)
                {
                    password_check=password.getText().toString();
                    set=1;
                    password_heading.setText(R.string.confirm_password);
                    password.setText("");
                }
                else if(set ==1)
                {
                    String c_pass=password.getText().toString();
                    if(password_check.equals(c_pass))
                    {
                        DBFunction dbFunction=new DBFunction(PasswordSettingScreen.this);
                        dbFunction.updatePassword(password_check,"set");

                        Intent intent=new Intent(PasswordSettingScreen.this,Home.class);
                        startActivity(intent);
                        finish();
                    }
                    else
                    {
                        Toast.makeText(PasswordSettingScreen.this, "Password doesn't match", Toast.LENGTH_SHORT).show();

                    }
                }
                else if (set==3)
                {

                    DBFunction dbFunction=new DBFunction(PasswordSettingScreen.this);
                    String pass=dbFunction.fetchPassword();

                    if(pass.equals(password.getText().toString()))
                    {
                        Intent intent=new Intent(PasswordSettingScreen.this,Home.class);
                        startActivity(intent);
                        finish();
                    }
                    else
                    {
                        Toast.makeText(PasswordSettingScreen.this, "Incorrect Password", Toast.LENGTH_SHORT).show();

                    }

                }
                else if (set==4)
                {

                    DBFunction dbFunction=new DBFunction(PasswordSettingScreen.this);
                    String pass=dbFunction.fetchPassword();

                    if(pass.equals(password.getText().toString()))
                    {
                        set=0;
                        password_heading.setText("Set Password");
                        password.setText("");
                    }
                    else
                    {
                        Toast.makeText(PasswordSettingScreen.this, "Incorrect Password", Toast.LENGTH_SHORT).show();

                    }

                }

                else if (set==5)
                {

                    DBFunction dbFunction=new DBFunction(PasswordSettingScreen.this);
                    String pass=dbFunction.fetchPassword();

                    if(pass.equals(password.getText().toString()))
                    {
                        set=0;
                        dbFunction.updatePassword("","clear");

                        Intent intent=new Intent(PasswordSettingScreen.this,Profile_Settings.class);
                        startActivity(intent);
                        finish();

                    }
                    else
                    {
                        Toast.makeText(PasswordSettingScreen.this, "Incorrect Password", Toast.LENGTH_SHORT).show();

                    }

                }


            }
        });

    }
}

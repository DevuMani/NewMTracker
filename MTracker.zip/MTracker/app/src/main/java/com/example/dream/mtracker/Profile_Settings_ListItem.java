package com.example.dream.mtracker;

public class Profile_Settings_ListItem {

    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
